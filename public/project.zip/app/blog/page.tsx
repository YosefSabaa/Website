'use client';

import * as React from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Calendar, Clock, ArrowLeft, Search, Tag } from 'lucide-react';
import { SiteLayout } from '@/components/shared/site-layout';
import { Breadcrumb } from '@/components/shared/breadcrumb';
import { blogPosts } from '@/lib/data';
import { cn } from '@/lib/utils';

const categories = ['الكل', 'نصائح مدرسية', 'نصائح دراسية', 'تربية وتعليم'];

export default function BlogPage() {
  const [activeCat, setActiveCat] = React.useState('الكل');
  const [search, setSearch] = React.useState('');

  const filtered = blogPosts.filter((p) => {
    if (activeCat !== 'الكل' && p.category !== activeCat) return false;
    if (search && !p.title.includes(search)) return false;
    return true;
  });

  return (
    <SiteLayout>
      <div className="container-px mx-auto max-w-7xl py-6">
        <Breadcrumb items={[{ label: 'الرئيسية', href: '/' }, { label: 'المدونة' }]} />

        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 text-center"
        >
          <h1 className="text-3xl font-extrabold sm:text-4xl">مدونة المركز العلمي</h1>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            نصائح ومقالات تعليمية مفيدة للطلاب وأولياء الأمور والمعلمين
          </p>
        </motion.div>

        {/* Search + categories */}
        <div className="mt-8 flex flex-col items-center gap-4">
          <div className="relative w-full max-w-md">
            <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث في المقالات..."
              className="w-full rounded-xl border border-input bg-background py-2.5 pr-10 pl-3 text-sm outline-none"
            />
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setActiveCat(c)}
                className={cn(
                  'rounded-full px-4 py-2 text-sm font-medium transition-colors',
                  activeCat === c ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:bg-muted/70'
                )}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Articles */}
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((post, i) => (
            <motion.article
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass-card group overflow-hidden rounded-2xl transition-all hover:shadow-soft-lg hover:-translate-y-1"
            >
              <Link href={`/blog/${post.slug}`}>
                <div className="relative aspect-[16/10] overflow-hidden">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={post.image} alt={post.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" />
                  <span className="absolute top-3 right-3 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-white">
                    {post.category}
                  </span>
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><Calendar size={12} /> {post.date}</span>
                    <span className="flex items-center gap-1"><Clock size={12} /> {post.readTime}</span>
                  </div>
                  <h2 className="mt-3 line-clamp-2 text-lg font-bold transition-colors group-hover:text-primary">{post.title}</h2>
                  <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{post.excerpt}</p>
                  <div className="mt-4 flex items-center gap-2">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={post.authorAvatar} alt={post.author} className="h-8 w-8 rounded-full object-cover" />
                    <span className="text-xs font-medium">{post.author}</span>
                  </div>
                </div>
              </Link>
            </motion.article>
          ))}
        </div>
      </div>
    </SiteLayout>
  );
}
