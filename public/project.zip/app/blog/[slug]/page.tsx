'use client';

import * as React from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { motion } from 'framer-motion';
import {
  Calendar, Clock, ArrowLeft, Tag, MessageCircle, Send, ThumbsUp, Share2,
} from 'lucide-react';
import { SiteLayout } from '@/components/shared/site-layout';
import { Breadcrumb } from '@/components/shared/breadcrumb';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { blogPosts } from '@/lib/data';
import { toast } from 'sonner';

export default function ArticlePage() {
  const params = useParams();
  const slug = params.slug as string;
  const post = blogPosts.find((p) => p.slug === slug);
  const [comment, setComment] = React.useState('');

  if (!post) {
    return (
      <SiteLayout>
        <div className="container-px mx-auto max-w-7xl py-20 text-center">
          <h1 className="text-2xl font-bold">المقال غير موجود</h1>
          <Button asChild className="mt-4"><Link href="/blog">العودة للمدونة</Link></Button>
        </div>
      </SiteLayout>
    );
  }

  const related = blogPosts.filter((p) => p.id !== post.id && p.category === post.category).slice(0, 3);
  const paragraphs = post.content.split('. ').filter(Boolean);

  const handleComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim()) return;
    toast.success('تم نشر تعليقك بنجاح');
    setComment('');
  };

  return (
    <SiteLayout>
      <div className="container-px mx-auto max-w-3xl py-6">
        <Breadcrumb
          items={[
            { label: 'الرئيسية', href: '/' },
            { label: 'المدونة', href: '/blog' },
            { label: post.title },
          ]}
        />

        {/* Article header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-6">
          <span className="inline-block rounded-full bg-primary px-3 py-1 text-xs font-semibold text-white">
            {post.category}
          </span>
          <h1 className="mt-4 text-3xl font-extrabold leading-tight sm:text-4xl">{post.title}</h1>
          <div className="mt-4 flex items-center gap-4">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={post.authorAvatar} alt={post.author} className="h-12 w-12 rounded-full object-cover" />
            <div>
              <p className="font-semibold">{post.author}</p>
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Calendar size={12} /> {post.date}</span>
                <span className="flex items-center gap-1"><Clock size={12} /> {post.readTime}</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Featured image */}
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="mt-6 overflow-hidden rounded-2xl">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={post.image} alt={post.title} className="w-full" />
        </motion.div>

        {/* Content */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="mt-8">
          <div className="space-y-4 text-base leading-loose text-foreground/80">
            {paragraphs.map((p, i) => (
              <p key={i}>{p}.</p>
            ))}
          </div>

          {/* Tags */}
          <div className="mt-8 flex flex-wrap gap-2">
            {post.tags.map((tag) => (
              <span key={tag} className="flex items-center gap-1 rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">
                <Tag size={10} /> {tag}
              </span>
            ))}
          </div>

          {/* Actions */}
          <div className="mt-6 flex items-center gap-3 border-y border-border py-4">
            <button onClick={() => toast.success('أعجبتك المقالة')} className="flex items-center gap-1.5 rounded-lg border border-border px-4 py-2 text-sm transition-colors hover:bg-muted">
              <ThumbsUp size={16} /> أعجبني
            </button>
            <button onClick={() => { navigator.clipboard.writeText(window.location.href); toast.success('تم نسخ الرابط'); }} className="flex items-center gap-1.5 rounded-lg border border-border px-4 py-2 text-sm transition-colors hover:bg-muted">
              <Share2 size={16} /> مشاركة
            </button>
          </div>
        </motion.div>

        {/* Comments */}
        <section className="mt-10">
          <h2 className="flex items-center gap-2 text-xl font-bold">
            <MessageCircle size={20} className="text-primary" /> التعليقات (3)
          </h2>

          {/* Comment form */}
          <form onSubmit={handleComment} className="mt-4 glass-card rounded-2xl p-5">
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="أضف تعليقاً..."
              rows={3}
            />
            <Button type="submit" className="mt-3 gap-2">
              <Send size={16} /> نشر التعليق
            </Button>
          </form>

          {/* Comments list */}
          <div className="mt-6 space-y-4">
            {[
              { name: 'أحمد محمد', date: 'منذ يومين', text: 'مقال رائع ومفيد جداً، شكراً لكم على هذه النصائح القيمة!' },
              { name: 'فاطمة علي', date: 'منذ 3 أيام', text: 'استفدت كثيراً من هذه النصائح، خاصة ما يتعلق بتنظيم وقت الدراسة.' },
              { name: 'خالد سعيد', date: 'منذ أسبوع', text: 'مقال ممتاز، أنصح الجميع بقراءته قبل بداية العام الدراسي.' },
            ].map((c, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass-card rounded-2xl p-5"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full brand-gradient-bg text-sm font-bold text-white">
                    {c.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-semibold">{c.name}</h4>
                    <p className="text-xs text-muted-foreground">{c.date}</p>
                  </div>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-foreground/80">{c.text}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Related posts */}
        {related.length > 0 && (
          <section className="mt-12">
            <h2 className="mb-6 text-xl font-bold">مقالات ذات صلة</h2>
            <div className="grid gap-4 sm:grid-cols-3">
              {related.map((p, i) => (
                <Link key={p.id} href={`/blog/${p.slug}`} className="glass-card group overflow-hidden rounded-xl transition-all hover:shadow-soft">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={p.image} alt={p.title} className="aspect-video w-full object-cover transition-transform group-hover:scale-105" />
                  <div className="p-3">
                    <h3 className="line-clamp-2 text-sm font-semibold group-hover:text-primary">{p.title}</h3>
                    <p className="mt-1 text-xs text-muted-foreground">{p.readTime}</p>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>
    </SiteLayout>
  );
}
