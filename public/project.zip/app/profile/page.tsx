'use client';

import * as React from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  LayoutDashboard, Package, Heart, MapPin, Bell, Tag, Settings, LogOut,
  ShoppingBag, TrendingUp, Clock, CheckCircle2, Truck, User,
} from 'lucide-react';
import { SiteLayout } from '@/components/shared/site-layout';
import { Breadcrumb } from '@/components/shared/breadcrumb';
import { Button } from '@/components/ui/button';
import { orders, formatPrice } from '@/lib/data';
import { useWishlist } from '@/lib/context/wishlist-context';
import { cn } from '@/lib/utils';

const navItems = [
  { label: 'لوحة التحكم', icon: LayoutDashboard, key: 'dashboard' },
  { label: 'طلباتي', icon: Package, key: 'orders', href: '/orders' },
  { label: 'المفضلة', icon: Heart, key: 'wishlist', href: '/wishlist' },
  { label: 'العناوين', icon: MapPin, key: 'addresses' },
  { label: 'الإشعارات', icon: Bell, key: 'notifications' },
  { label: 'الكوبونات', icon: Tag, key: 'coupons' },
  { label: 'الإعدادات', icon: Settings, key: 'settings' },
];

const statusConfig = {
  pending: { label: 'قيد الانتظار', color: 'bg-warning/15 text-warning' },
  processing: { label: 'جاري التجهيز', color: 'bg-primary/15 text-primary' },
  shipped: { label: 'تم الشحن', color: 'bg-primary/15 text-primary' },
  delivered: { label: 'تم التوصيل', color: 'bg-success/15 text-success' },
  cancelled: { label: 'ملغي', color: 'bg-destructive/15 text-destructive' },
};

const coupons = [
  { code: 'SAVE10', discount: '10%', desc: 'خصم 10% على جميع المنتجات', expiry: '31 أغسطس 2026', used: false },
  { code: 'WELCOME15', discount: '15%', desc: 'خصم 15% للعملاء الجدد', expiry: '30 سبتمبر 2026', used: false },
  { code: 'SCHOOL20', discount: '20%', desc: 'خصم 20% على الأدوات المدرسية', expiry: 'منتهي', used: true },
];

const notifications = [
  { title: 'تم شحن طلبك', desc: 'طلب SC-2026-1051 تم شحنه وسيصلك خلال 2 أيام', time: 'منذ ساعة', unread: true },
  { title: 'عرض حصري', desc: 'خصم 25% على الكتب الخارجية لفترة محدودة', time: 'منذ 3 ساعات', unread: true },
  { title: 'تأكيد الطلب', desc: 'تم تأكيد طلبك SC-2026-1058 بنجاح', time: 'منذ يوم', unread: false },
];

export default function ProfilePage() {
  const [activeTab, setActiveTab] = React.useState('dashboard');
  const { count: wishlistCount } = useWishlist();

  const dashboardStats = [
    { label: 'إجمالي الطلبات', value: '12', icon: ShoppingBag, color: 'text-primary' },
    { label: 'قيد التوصيل', value: '2', icon: Truck, color: 'text-warning' },
    { label: 'تم التوصيل', value: '9', icon: CheckCircle2, color: 'text-success' },
    { label: 'في المفضلة', value: String(wishlistCount), icon: Heart, color: 'text-danger' },
  ];

  return (
    <SiteLayout>
      <div className="container-px mx-auto max-w-7xl py-6">
        <Breadcrumb items={[{ label: 'الرئيسية', href: '/' }, { label: 'حسابي' }]} />

        <h1 className="mt-4 text-2xl font-bold">حسابي</h1>

        <div className="mt-6 grid gap-6 lg:grid-cols-4">
          {/* Sidebar */}
          <aside className="lg:col-span-1">
            <div className="glass-card sticky top-40 overflow-hidden rounded-2xl">
              {/* User info */}
              <div className="brand-gradient-bg p-6 text-center text-white">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-white/20 text-2xl font-bold backdrop-blur">
                  م
                </div>
                <h3 className="mt-3 font-bold">محمد العبدالله</h3>
                <p className="text-xs text-white/80">example@mail.com</p>
              </div>

              {/* Nav */}
              <nav className="p-3">
                {navItems.map((item) => {
                  const content = (
                    <button
                      onClick={() => !item.href && setActiveTab(item.key)}
                      className={cn(
                        'flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium transition-colors',
                        activeTab === item.key ? 'bg-primary text-primary-foreground' : 'text-foreground hover:bg-muted'
                      )}
                    >
                      <item.icon size={18} />
                      {item.label}
                    </button>
                  );
                  return item.href ? (
                    <Link key={item.key} href={item.href}>
                      <div className="flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-muted">
                        <item.icon size={18} />
                        {item.label}
                      </div>
                    </Link>
                  ) : (
                    <div key={item.key}>{content}</div>
                  );
                })}

                <div className="my-2 h-px bg-border" />
                <Link href="/" className="flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium text-destructive transition-colors hover:bg-destructive/10">
                  <LogOut size={18} />
                  تسجيل الخروج
                </Link>
              </nav>
            </div>
          </aside>

          {/* Content */}
          <div className="lg:col-span-3">
            {activeTab === 'dashboard' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                {/* Stats */}
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                  {dashboardStats.map((s, i) => (
                    <motion.div
                      key={s.label}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.1 }}
                      className="glass-card rounded-2xl p-4 text-center"
                    >
                      <s.icon size={24} className={cn('mx-auto mb-2', s.color)} />
                      <div className="text-2xl font-extrabold text-foreground">{s.value}</div>
                      <div className="text-xs text-muted-foreground">{s.label}</div>
                    </motion.div>
                  ))}
                </div>

                {/* Recent orders */}
                <div className="mt-6 glass-card rounded-2xl p-6">
                  <div className="mb-4 flex items-center justify-between">
                    <h2 className="flex items-center gap-2 font-bold">
                      <Clock size={18} className="text-primary" /> آخر الطلبات
                    </h2>
                    <Link href="/orders" className="text-sm text-primary hover:underline">عرض الكل</Link>
                  </div>
                  <div className="space-y-3">
                    {orders.slice(0, 3).map((order) => (
                      <div key={order.id} className="flex items-center gap-4 rounded-xl border border-border p-3">
                        <div className="flex -space-x-2">
                          {order.items.slice(0, 3).map((item, i) => (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img key={i} src={item.image} alt={item.name} className="h-12 w-12 rounded-lg border-2 border-background object-cover" />
                          ))}
                        </div>
                        <div className="flex-1">
                          <h4 className="text-sm font-semibold" dir="ltr">{order.number}</h4>
                          <p className="text-xs text-muted-foreground">{order.date}</p>
                        </div>
                        <span className={cn('rounded-full px-3 py-1 text-xs font-semibold', statusConfig[order.status].color)}>
                          {statusConfig[order.status].label}
                        </span>
                        <span className="font-bold text-primary">{formatPrice(order.total)} ر.س</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quick actions */}
                <div className="mt-6 grid gap-4 sm:grid-cols-3">
                  <Link href="/orders" className="glass-card flex items-center gap-3 rounded-2xl p-4 transition-all hover:shadow-soft">
                    <Package size={22} className="text-primary" />
                    <span className="font-semibold">تتبع الطلبات</span>
                  </Link>
                  <Link href="/wishlist" className="glass-card flex items-center gap-3 rounded-2xl p-4 transition-all hover:shadow-soft">
                    <Heart size={22} className="text-danger" />
                    <span className="font-semibold">المفضلة</span>
                  </Link>
                  <Link href="/track-order" className="glass-card flex items-center gap-3 rounded-2xl p-4 transition-all hover:shadow-soft">
                    <TrendingUp size={22} className="text-success" />
                    <span className="font-semibold">تتبع شحنة</span>
                  </Link>
                </div>
              </motion.div>
            )}

            {activeTab === 'addresses' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold">عناويني</h2>
                  <Button>إضافة عنوان</Button>
                </div>
                {[
                  { label: 'المنزل', address: 'الرياض، حي النرجس، شارع الأمير محمد، مبنى 24', phone: '0512345678', default: true },
                  { label: 'العمل', address: 'الرياض، حي العليا، طريق الملك فهد، برج 12', phone: '0587654321', default: false },
                ].map((addr, i) => (
                  <div key={i} className="glass-card rounded-2xl p-5">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold">{addr.label}</h3>
                          {addr.default && <span className="rounded-full bg-success/15 px-2 py-0.5 text-xs font-semibold text-success">افتراضي</span>}
                        </div>
                        <p className="mt-2 flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin size={14} /> {addr.address}
                        </p>
                        <p className="mt-1 text-sm text-muted-foreground" dir="ltr">{addr.phone}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm">تعديل</Button>
                        <Button variant="ghost" size="sm" className="text-destructive">حذف</Button>
                      </div>
                    </div>
                  </div>
                ))}
              </motion.div>
            )}

            {activeTab === 'notifications' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
                <h2 className="mb-2 text-lg font-bold">الإشعارات</h2>
                {notifications.map((n, i) => (
                  <div key={i} className={cn('glass-card rounded-2xl p-4', n.unread && 'ring-1 ring-primary/30')}>
                    <div className="flex items-start gap-3">
                      <div className={cn('flex h-10 w-10 shrink-0 items-center justify-center rounded-xl', n.unread ? 'bg-primary/10' : 'bg-muted')}>
                        <Bell size={18} className={n.unread ? 'text-primary' : 'text-muted-foreground'} />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold">{n.title}</h3>
                        <p className="text-sm text-muted-foreground">{n.desc}</p>
                        <p className="mt-1 text-xs text-muted-foreground">{n.time}</p>
                      </div>
                      {n.unread && <div className="h-2 w-2 rounded-full bg-primary" />}
                    </div>
                  </div>
                ))}
              </motion.div>
            )}

            {activeTab === 'coupons' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
                <h2 className="mb-4 text-lg font-bold">كوبوناتي</h2>
                <div className="grid gap-4 sm:grid-cols-2">
                  {coupons.map((c) => (
                    <div key={c.code} className={cn('relative overflow-hidden rounded-2xl p-5', c.used ? 'bg-muted/50' : 'glass-card')}>
                      <div className="absolute -right-4 top-1/2 h-12 w-12 -translate-y-1/2 rounded-full border border-border bg-background" />
                      <div className="absolute -left-4 top-1/2 h-12 w-12 -translate-y-1/2 rounded-full border border-border bg-background" />
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-2xl font-extrabold text-primary">{c.discount}</span>
                          <span className="text-sm text-muted-foreground"> خصم</span>
                        </div>
                        {c.used ? (
                          <span className="rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground">مستخدم</span>
                        ) : (
                          <span className="rounded-full bg-success/15 px-3 py-1 text-xs font-semibold text-success">متاح</span>
                        )}
                      </div>
                      <p className="mt-2 text-sm font-medium text-foreground">{c.desc}</p>
                      <div className="mt-3 flex items-center justify-between">
                        <span className="font-mono text-sm font-bold text-primary" dir="ltr">{c.code}</span>
                        <span className="text-xs text-muted-foreground">ينتهي: {c.expiry}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'settings' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card rounded-2xl p-6">
                <h2 className="mb-4 flex items-center gap-2 text-lg font-bold">
                  <User size={20} className="text-primary" /> الإعدادات
                </h2>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <label className="text-sm font-medium">الاسم الأول</label>
                    <input defaultValue="محمد" className="mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none" />
                  </div>
                  <div>
                    <label className="text-sm font-medium">الاسم الأخير</label>
                    <input defaultValue="العبدالله" className="mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none" />
                  </div>
                  <div>
                    <label className="text-sm font-medium">البريد الإلكتروني</label>
                    <input defaultValue="example@mail.com" dir="ltr" className="mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none" />
                  </div>
                  <div>
                    <label className="text-sm font-medium">رقم الجوال</label>
                    <input defaultValue="0512345678" dir="ltr" className="mt-1.5 w-full rounded-lg border border-input bg-background px-3 py-2.5 text-sm outline-none" />
                  </div>
                </div>
                <div className="mt-4 space-y-3">
                  {['إشعارات العروض والخصومات', 'إشعارات حالة الطلب', 'النشرة البريدية الأسبوعية'].map((label) => (
                    <label key={label} className="flex items-center justify-between rounded-xl border border-border p-3">
                      <span className="text-sm">{label}</span>
                      <input type="checkbox" defaultChecked className="h-5 w-5 accent-primary" />
                    </label>
                  ))}
                </div>
                <Button className="mt-4">حفظ التغييرات</Button>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </SiteLayout>
  );
}
