'use client';

import * as React from 'react';
import { motion } from 'framer-motion';
import { Search, Plus, Edit, Trash2, Eye, Package, AlertTriangle } from 'lucide-react';
import { AdminLayout } from '@/components/shared/admin-layout';
import { products, categories, formatPrice } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

export default function AdminProductsPage() {
  const [search, setSearch] = React.useState('');
  const [categoryFilter, setCategoryFilter] = React.useState('all');

  const filtered = products.filter((p) => {
    if (categoryFilter !== 'all' && p.categorySlug !== categoryFilter) return false;
    if (search && !p.name.includes(search)) return false;
    return true;
  });

  return (
    <AdminLayout activeKey="products">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">إدارة المنتجات</h1>
          <p className="text-sm text-muted-foreground">{products.length} منتج</p>
        </div>
        <Button className="gap-2">
          <Plus size={18} /> إضافة منتج
        </Button>
      </div>

      {/* Filters */}
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setCategoryFilter('all')}
            className={cn('rounded-lg px-4 py-2 text-sm font-medium', categoryFilter === 'all' ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:bg-muted')}
          >
            الكل
          </button>
          {categories.slice(0, 6).map((c) => (
            <button
              key={c.id}
              onClick={() => setCategoryFilter(c.slug)}
              className={cn('rounded-lg px-4 py-2 text-sm font-medium', categoryFilter === c.slug ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:bg-muted')}
            >
              {c.name}
            </button>
          ))}
        </div>
        <div className="relative">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث عن منتج..."
            className="w-full rounded-lg border border-input bg-card py-2.5 pr-9 pl-3 text-sm outline-none sm:w-64"
          />
        </div>
      </div>

      {/* Table */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card overflow-hidden rounded-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/30">
              <tr className="text-xs text-muted-foreground">
                <th className="px-4 py-3 text-right font-semibold">المنتج</th>
                <th className="px-4 py-3 text-right font-semibold">الفئة</th>
                <th className="px-4 py-3 text-right font-semibold">السعر</th>
                <th className="px-4 py-3 text-right font-semibold">المخزون</th>
                <th className="px-4 py-3 text-right font-semibold">الحالة</th>
                <th className="px-4 py-3 text-right font-semibold">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id} className="border-t border-border hover:bg-muted/20">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={p.images[0]} alt={p.name} className="h-12 w-12 rounded-lg object-cover" />
                      <div className="min-w-0">
                        <h4 className="line-clamp-1 font-semibold">{p.name}</h4>
                        <p className="text-xs text-muted-foreground">{p.sku}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{p.category}</td>
                  <td className="px-4 py-3 font-bold text-primary">{formatPrice(p.price)} ر.س</td>
                  <td className="px-4 py-3">
                    <span className={cn(
                      'flex items-center gap-1 font-medium',
                      p.stock <= 0 ? 'text-destructive' : p.stock <= 10 ? 'text-warning' : 'text-success'
                    )}>
                      {p.stock <= 10 && <AlertTriangle size={12} />}
                      {p.stock}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={cn(
                      'rounded-full px-2.5 py-1 text-xs font-semibold',
                      p.stock > 0 ? 'bg-success/15 text-success' : 'bg-destructive/15 text-destructive'
                    )}>
                      {p.stock > 0 ? 'متاح' : 'نفذت'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      <button className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-primary/10 hover:text-primary">
                        <Eye size={16} />
                      </button>
                      <button className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-primary/10 hover:text-primary">
                        <Edit size={16} />
                      </button>
                      <button className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive">
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </AdminLayout>
  );
}
