'use client';

import { motion } from 'framer-motion';
import { Search, Mail, Phone, Eye, ShoppingBag, TrendingUp } from 'lucide-react';
import { AdminLayout } from '@/components/shared/admin-layout';
import { formatPrice } from '@/lib/data';

const customers = [
  { name: 'محمد العبدالله', email: 'mohammed@mail.com', phone: '0512345678', orders: 12, spent: 4200, avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150', joinDate: '2024-01-15' },
  { name: 'سارة المطيري', email: 'sara@mail.com', phone: '0587654321', orders: 8, spent: 3100, avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150', joinDate: '2024-03-22' },
  { name: 'عبد الرحمن السالم', email: 'abdulrahman@mail.com', phone: '0555123456', orders: 15, spent: 5800, avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150', joinDate: '2023-11-08' },
  { name: 'هند العتيبي', email: 'hind@mail.com', phone: '0533445566', orders: 6, spent: 2400, avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150', joinDate: '2024-05-14' },
  { name: 'فاطمة علي', email: 'fatima@mail.com', phone: '0599887766', orders: 9, spent: 3650, avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150', joinDate: '2024-02-10' },
  { name: 'خالد سعيد', email: 'khalid@mail.com', phone: '0577889900', orders: 4, spent: 1850, avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=150', joinDate: '2024-06-20' },
];

export default function AdminCustomersPage() {
  return (
    <AdminLayout activeKey="customers">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">العملاء</h1>
        <p className="text-sm text-muted-foreground">إدارة بيانات العملاء</p>
      </div>

      {/* Stats */}
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: 'إجمالي العملاء', value: '15,420', icon: ShoppingBag },
          { label: 'عملاء جدد هذا الشهر', value: '342', icon: TrendingUp },
          { label: 'العملاء النشطون', value: '8,230', icon: ShoppingBag },
          { label: 'متوسط الطلب', value: '425 ر.س', icon: TrendingUp },
        ].map((s) => (
          <div key={s.label} className="glass-card rounded-2xl p-4">
            <s.icon size={20} className="mb-2 text-primary" />
            <div className="text-2xl font-extrabold">{s.value}</div>
            <div className="text-xs text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="mb-4 flex items-center justify-between">
        <div className="relative">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            placeholder="ابحث عن عميل..."
            className="w-full rounded-lg border border-input bg-card py-2.5 pr-9 pl-3 text-sm outline-none sm:w-64"
          />
        </div>
      </div>

      {/* Table */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card overflow-hidden rounded-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/30">
              <tr className="text-xs text-muted-foreground">
                <th className="px-4 py-3 text-right font-semibold">العميل</th>
                <th className="px-4 py-3 text-right font-semibold">التواصل</th>
                <th className="px-4 py-3 text-right font-semibold">الطلبات</th>
                <th className="px-4 py-3 text-right font-semibold">إجمالي الإنفاق</th>
                <th className="px-4 py-3 text-right font-semibold">تاريخ الانضمام</th>
                <th className="px-4 py-3 text-right font-semibold">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {customers.map((c) => (
                <tr key={c.email} className="border-t border-border hover:bg-muted/20">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={c.avatar} alt={c.name} className="h-10 w-10 rounded-full object-cover" />
                      <span className="font-semibold">{c.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-0.5 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><Mail size={12} /> <span dir="ltr">{c.email}</span></span>
                      <span className="flex items-center gap-1"><Phone size={12} /> <span dir="ltr">{c.phone}</span></span>
                    </div>
                  </td>
                  <td className="px-4 py-3 font-semibold">{c.orders}</td>
                  <td className="px-4 py-3 font-bold text-primary">{formatPrice(c.spent)} ر.س</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.joinDate}</td>
                  <td className="px-4 py-3">
                    <button className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-primary/10 hover:text-primary">
                      <Eye size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </AdminLayout>
  );
}
