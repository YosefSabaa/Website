'use client';

import * as React from 'react';
import { motion } from 'framer-motion';
import { Search, Eye, Download, Filter } from 'lucide-react';
import { AdminLayout } from '@/components/shared/admin-layout';
import { orders, formatPrice } from '@/lib/data';
import { cn } from '@/lib/utils';

const statusConfig = {
  pending: { label: 'قيد الانتظار', color: 'bg-warning/15 text-warning' },
  processing: { label: 'قيد التجهيز', color: 'bg-primary/15 text-primary' },
  shipped: { label: 'تم الشحن', color: 'bg-blue-500/15 text-blue-500' },
  delivered: { label: 'تم التوصيل', color: 'bg-success/15 text-success' },
  cancelled: { label: 'ملغي', color: 'bg-destructive/15 text-destructive' },
};

export default function AdminOrdersPage() {
  const [filter, setFilter] = React.useState('all');
  const [search, setSearch] = React.useState('');

  const filtered = orders.filter((o) => {
    if (filter !== 'all' && o.status !== filter) return false;
    if (search && !o.number.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <AdminLayout activeKey="orders">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">إدارة الطلبات</h1>
        <p className="text-sm text-muted-foreground">عرض وإدارة جميع الطلبات</p>
      </div>

      {/* Stats */}
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: 'إجمالي الطلبات', value: '1,254' },
          { label: 'قيد التجهيز', value: '23' },
          { label: 'تم الشحن', value: '87' },
          { label: 'تم التوصيل', value: '1,118' },
        ].map((s) => (
          <div key={s.label} className="glass-card rounded-2xl p-4">
            <div className="text-2xl font-extrabold">{s.value}</div>
            <div className="text-xs text-muted-foreground">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          {['all', 'processing', 'shipped', 'delivered', 'cancelled'].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                'rounded-lg px-4 py-2 text-sm font-medium transition-colors',
                filter === f ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground hover:bg-muted'
              )}
            >
              {f === 'all' ? 'الكل' : statusConfig[f as keyof typeof statusConfig].label}
            </button>
          ))}
        </div>
        <div className="relative">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث برقم الطلب..."
            className="w-full rounded-lg border border-input bg-card py-2.5 pr-9 pl-3 text-sm outline-none sm:w-64"
            dir="ltr"
          />
        </div>
      </div>

      {/* Table */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-card overflow-hidden rounded-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/30">
              <tr className="text-xs text-muted-foreground">
                <th className="px-4 py-3 text-right font-semibold">رقم الطلب</th>
                <th className="px-4 py-3 text-right font-semibold">التاريخ</th>
                <th className="px-4 py-3 text-right font-semibold">العميل</th>
                <th className="px-4 py-3 text-right font-semibold">المنتجات</th>
                <th className="px-4 py-3 text-right font-semibold">المبلغ</th>
                <th className="px-4 py-3 text-right font-semibold">الحالة</th>
                <th className="px-4 py-3 text-right font-semibold">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((order, i) => (
                <tr key={order.id} className="border-t border-border hover:bg-muted/20">
                  <td className="px-4 py-3 font-semibold" dir="ltr">{order.number}</td>
                  <td className="px-4 py-3 text-muted-foreground">{order.date}</td>
                  <td className="px-4 py-3">محمد العبدالله</td>
                  <td className="px-4 py-3 text-muted-foreground">{order.items.length} منتج</td>
                  <td className="px-4 py-3 font-bold text-primary">{formatPrice(order.total)} ر.س</td>
                  <td className="px-4 py-3">
                    <span className={cn('rounded-full px-2.5 py-1 text-xs font-semibold', statusConfig[order.status].color)}>
                      {statusConfig[order.status].label}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      <button className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-primary/10 hover:text-primary">
                        <Eye size={16} />
                      </button>
                      <button className="flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground hover:bg-primary/10 hover:text-primary">
                        <Download size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </AdminLayout>
  );
}
