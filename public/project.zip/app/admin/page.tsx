'use client';

import { motion } from 'framer-motion';
import {
  TrendingUp, TrendingDown, ShoppingCart, Users, Package, DollarSign,
  ArrowLeft, MoreHorizontal, Eye, Star,
} from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import { AdminLayout } from '@/components/shared/admin-layout';
import { orders, products, formatPrice } from '@/lib/data';
import { cn } from '@/lib/utils';

const salesData = [
  { name: 'يناير', sales: 4200, orders: 120 },
  { name: 'فبراير', sales: 5100, orders: 145 },
  { name: 'مارس', sales: 4800, orders: 132 },
  { name: 'أبريل', sales: 6200, orders: 178 },
  { name: 'مايو', sales: 7500, orders: 210 },
  { name: 'يونيو', sales: 8900, orders: 245 },
  { name: 'يوليو', sales: 11200, orders: 320 },
];

const categoryData = [
  { name: 'الكتب', value: 35, color: '#2563EB' },
  { name: 'القرطاسية', value: 25, color: '#3B82F6' },
  { name: 'الأدوات المدرسية', value: 20, color: '#60A5FA' },
  { name: 'الهدايا', value: 12, color: '#16A34A' },
  { name: 'أخرى', value: 8, color: '#F59E0B' },
];

const stats = [
  { label: 'مبيعات اليوم', value: '12,450 ر.س', change: '+12.5%', trend: 'up', icon: DollarSign, color: 'text-success', bg: 'bg-success/10' },
  { label: 'طلبات اليوم', value: '87', change: '+8.2%', trend: 'up', icon: ShoppingCart, color: 'text-primary', bg: 'bg-primary/10' },
  { label: 'عملاء جدد', value: '34', change: '+15.3%', trend: 'up', icon: Users, color: 'text-primary', bg: 'bg-primary/10' },
  { label: 'منتجات منخفضة', value: '12', change: '-3.1%', trend: 'down', icon: Package, color: 'text-warning', bg: 'bg-warning/10' },
];

export default function AdminDashboardPage() {
  return (
    <AdminLayout activeKey="dashboard">
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">لوحة التحكم</h1>
          <p className="text-sm text-muted-foreground">مرحباً بك، إليك نظرة عامة على متجرك</p>
        </div>
        <button className="flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm hover:bg-muted">
          آخر 7 أيام <ArrowLeft size={14} />
        </button>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass-card rounded-2xl p-5"
          >
            <div className="flex items-center justify-between">
              <div className={cn('flex h-11 w-11 items-center justify-center rounded-xl', s.bg)}>
                <s.icon size={20} className={s.color} />
              </div>
              <span className={cn('flex items-center gap-1 text-xs font-semibold', s.trend === 'up' ? 'text-success' : 'text-destructive')}>
                {s.trend === 'up' ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                {s.change}
              </span>
            </div>
            <div className="mt-3 text-2xl font-extrabold text-foreground">{s.value}</div>
            <div className="text-xs text-muted-foreground">{s.label}</div>
          </motion.div>
        ))}
      </div>

      {/* Charts */}
      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        {/* Sales chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="glass-card rounded-2xl p-6 lg:col-span-2"
        >
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-bold">مبيعات الأشهر الماضية</h2>
            <button className="text-muted-foreground hover:text-foreground"><MoreHorizontal size={18} /></button>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={salesData}>
              <defs>
                <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#2563EB" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
              <YAxis tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '12px',
                  fontSize: '13px',
                }}
              />
              <Area
                type="monotone"
                dataKey="sales"
                stroke="#2563EB"
                strokeWidth={2}
                fill="url(#salesGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Category pie */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass-card rounded-2xl p-6"
        >
          <h2 className="mb-4 font-bold">توزيع المبيعات حسب الفئة</h2>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={3}
                dataKey="value"
              >
                {categoryData.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 space-y-2">
            {categoryData.map((c) => (
              <div key={c.name} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full" style={{ backgroundColor: c.color }} />
                  <span className="text-muted-foreground">{c.name}</span>
                </div>
                <span className="font-semibold">{c.value}%</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Orders chart + recent orders */}
      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        {/* Orders bar chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass-card rounded-2xl p-6"
        >
          <h2 className="mb-4 font-bold">عدد الطلبات</h2>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
              <YAxis tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '12px',
                  fontSize: '13px',
                }}
              />
              <Bar dataKey="orders" fill="#3B82F6" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Recent orders */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass-card rounded-2xl p-6 lg:col-span-2"
        >
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-bold">أحدث الطلبات</h2>
            <button className="text-sm text-primary hover:underline">عرض الكل</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-xs text-muted-foreground">
                  <th className="pb-3 text-right font-medium">رقم الطلب</th>
                  <th className="pb-3 text-right font-medium">العميل</th>
                  <th className="pb-3 text-right font-medium">المبلغ</th>
                  <th className="pb-3 text-right font-medium">الحالة</th>
                  <th className="pb-3 text-right font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id} className="border-b border-border/50 last:border-0">
                    <td className="py-3 font-semibold" dir="ltr">{order.number}</td>
                    <td className="py-3 text-muted-foreground">محمد العبدالله</td>
                    <td className="py-3 font-bold text-primary">{formatPrice(order.total)} ر.س</td>
                    <td className="py-3">
                      <span className={cn(
                        'rounded-full px-2.5 py-1 text-xs font-semibold',
                        order.status === 'delivered' && 'bg-success/15 text-success',
                        order.status === 'shipped' && 'bg-primary/15 text-primary',
                        order.status === 'processing' && 'bg-warning/15 text-warning',
                      )}>
                        {order.status === 'delivered' ? 'تم التوصيل' : order.status === 'shipped' ? 'تم الشحن' : 'قيد التجهيز'}
                      </span>
                    </td>
                    <td className="py-3">
                      <button className="text-muted-foreground hover:text-primary"><Eye size={16} /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>

      {/* Top products */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="mt-6 glass-card rounded-2xl p-6"
      >
        <h2 className="mb-4 font-bold">المنتجات الأكثر مبيعاً</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {products.filter((p) => p.isBestSeller).slice(0, 4).map((p) => (
            <div key={p.id} className="flex items-center gap-3 rounded-xl border border-border p-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={p.images[0]} alt={p.name} className="h-14 w-14 rounded-lg object-cover" />
              <div className="min-w-0 flex-1">
                <h4 className="line-clamp-1 text-sm font-semibold">{p.name}</h4>
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Star size={12} className="text-warning fill-warning" />
                  {p.rating} ({p.reviewsCount})
                </div>
                <p className="text-sm font-bold text-primary">{formatPrice(p.price)} ر.س</p>
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </AdminLayout>
  );
}
