'use client';

import * as React from 'react';
import { motion } from 'framer-motion';
import {
  MapPin, Phone, Mail, Clock, MessageCircle, Facebook, Instagram,
  Send, MapPinHouse,
} from 'lucide-react';
import { SiteLayout } from '@/components/shared/site-layout';
import { Breadcrumb } from '@/components/shared/breadcrumb';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

const contactMethods = [
  { icon: Phone, label: 'الهاتف', value: '800-124-5678', href: 'tel:8001245678', dir: 'ltr' },
  { icon: MessageCircle, label: 'واتساب', value: '050-123-4567', href: 'https://wa.me/966501234567', dir: 'ltr' },
  { icon: Mail, label: 'البريد الإلكتروني', value: 'info@sc-library.com', href: 'mailto:info@sc-library.com', dir: 'ltr' },
];

const socials = [
  { icon: Facebook, label: 'Facebook', href: '#' },
  { icon: Instagram, label: 'Instagram', href: '#' },
];

const hours = [
  { day: 'السبت - الأربعاء', time: '8:00 ص - 11:00 م' },
  { day: 'الخميس', time: '8:00 ص - 12:00 ص' },
  { day: 'الجمعة', time: '4:00 م - 11:00 م' },
];

export default function ContactPage() {
  const [loading, setLoading] = React.useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      toast.success('تم إرسال رسالتك بنجاح! سنتواصل معك قريباً');
      setLoading(false);
      (e.target as HTMLFormElement).reset();
    }, 1500);
  };

  return (
    <SiteLayout>
      <div className="container-px mx-auto max-w-7xl py-6">
        <Breadcrumb items={[{ label: 'الرئيسية', href: '/' }, { label: 'تواصل معنا' }]} />

        {/* Hero */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-6 text-center">
          <h1 className="text-3xl font-extrabold sm:text-4xl">تواصل معنا</h1>
          <p className="mx-auto mt-3 max-w-2xl text-muted-foreground">
            نحن هنا لمساعدتك. تواصل معنا عبر أي من الطرق التالية أو أرسل لنا رسالة مباشرة
          </p>
        </motion.div>

        {/* Contact methods */}
        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          {contactMethods.map((m, i) => (
            <motion.a
              key={m.label}
              href={m.href}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass-card flex flex-col items-center gap-3 rounded-2xl p-6 text-center transition-all hover:shadow-soft-lg hover:-translate-y-1"
            >
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl brand-gradient-bg text-white shadow-glow">
                <m.icon size={24} />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{m.label}</p>
                <p className="mt-1 font-bold text-foreground" dir={m.dir}>{m.value}</p>
              </div>
            </motion.a>
          ))}
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          {/* Form */}
          <motion.div initial={{ opacity: 0, x: 20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="glass-card rounded-2xl p-6">
            <h2 className="text-xl font-bold">أرسل لنا رسالة</h2>
            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="name">الاسم *</Label>
                  <Input id="name" required placeholder="اسمك الكامل" className="mt-1.5" />
                </div>
                <div>
                  <Label htmlFor="email">البريد الإلكتروني *</Label>
                  <Input id="email" type="email" required placeholder="example@mail.com" dir="ltr" className="mt-1.5" />
                </div>
              </div>
              <div>
                <Label htmlFor="phone">رقم الجوال</Label>
                <Input id="phone" type="tel" placeholder="05xxxxxxxx" dir="ltr" className="mt-1.5" />
              </div>
              <div>
                <Label htmlFor="subject">الموضوع *</Label>
                <Input id="subject" required placeholder="موضوع الرسالة" className="mt-1.5" />
              </div>
              <div>
                <Label htmlFor="message">الرسالة *</Label>
                <Textarea id="message" required placeholder="اكتب رسالتك هنا..." rows={5} className="mt-1.5" />
              </div>
              <Button type="submit" disabled={loading} className="w-full gap-2" size="lg">
                {loading ? (
                  <span className="h-5 w-5 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
                ) : (
                  <>
                    <Send size={18} /> إرسال الرسالة
                  </>
                )}
              </Button>
            </form>
          </motion.div>

          {/* Info + map + hours */}
          <div className="space-y-6">
            {/* Map placeholder */}
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="glass-card overflow-hidden rounded-2xl">
              <div className="relative flex h-56 items-center justify-center bg-muted">
                <div className="absolute inset-0 opacity-20" style={{
                  backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 20px, hsl(var(--border)) 20px, hsl(var(--border)) 21px), repeating-linear-gradient(90deg, transparent, transparent 20px, hsl(var(--border)) 20px, hsl(var(--border)) 21px)'
                }} />
                <div className="relative flex flex-col items-center gap-2 text-muted-foreground">
                  <MapPin size={40} className="text-primary" />
                  <p className="font-semibold">الرياض، المملكة العربية السعودية</p>
                  <p className="text-sm">حي النرجس، شارع الأمير محمد</p>
                </div>
              </div>
            </motion.div>

            {/* Address */}
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }} className="glass-card rounded-2xl p-6">
              <h3 className="flex items-center gap-2 font-bold">
                <MapPinHouse size={18} className="text-primary" /> العنوان
              </h3>
              <p className="mt-2 text-sm text-muted-foreground">
                المملكة العربية السعودية - الرياض<br />
                حي النرجس، شارع الأمير محمد بن سلمان<br />
                مبنى رقم 24، الدور الأول
              </p>
              <div className="mt-4 flex gap-2">
                {socials.map((s) => (
                  <a
                    key={s.label}
                    href={s.href}
                    aria-label={s.label}
                    className="flex h-10 w-10 items-center justify-center rounded-xl border border-border transition-all hover:border-primary hover:text-primary"
                  >
                    <s.icon size={18} />
                  </a>
                ))}
              </div>
            </motion.div>

            {/* Hours */}
            <motion.div initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: 0.2 }} className="glass-card rounded-2xl p-6">
              <h3 className="flex items-center gap-2 font-bold">
                <Clock size={18} className="text-primary" /> ساعات العمل
              </h3>
              <div className="mt-3 space-y-2">
                {hours.map((h) => (
                  <div key={h.day} className="flex items-center justify-between border-b border-border pb-2 text-sm last:border-0">
                    <span className="text-muted-foreground">{h.day}</span>
                    <span className="font-semibold">{h.time}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </SiteLayout>
  );
}
