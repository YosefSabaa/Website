'use client';

import * as React from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  LayoutDashboard, Package, ShoppingCart, Users, Tag, Star,
  BarChart3, Bell, Settings, LogOut, Menu, X, Package2, Search,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
  { label: 'لوحة التحكم', icon: LayoutDashboard, key: 'dashboard' },
  { label: 'الطلبات', icon: ShoppingCart, key: 'orders' },
  { label: 'المنتجات', icon: Package, key: 'products' },
  { label: 'الفئات', icon: Package2, key: 'categories' },
  { label: 'العملاء', icon: Users, key: 'customers' },
  { label: 'المخزون', icon: BarChart3, key: 'inventory' },
  { label: 'الكوبونات', icon: Tag, key: 'coupons' },
  { label: 'التقييمات', icon: Star, key: 'reviews' },
  { label: 'التقارير', icon: BarChart3, key: 'reports' },
  { label: 'الإشعارات', icon: Bell, key: 'notifications' },
  { label: 'الإعدادات', icon: Settings, key: 'settings' },
];

export function AdminLayout({ children, activeKey }: { children: React.ReactNode; activeKey: string }) {
  const [sidebarOpen, setSidebarOpen] = React.useState(false);

  return (
    <div className="flex min-h-screen bg-muted/30">
      {/* Sidebar - desktop */}
      <aside className="fixed inset-y-0 right-0 z-30 hidden w-64 border-l border-border bg-card lg:block">
        <AdminSidebar activeKey={activeKey} />
      </aside>

      {/* Sidebar - mobile */}
      {sidebarOpen && (
        <>
          <div className="fixed inset-0 z-40 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
          <aside className="fixed inset-y-0 right-0 z-50 w-64 border-l border-border bg-card lg:hidden">
            <button onClick={() => setSidebarOpen(false)} className="absolute left-4 top-4 text-muted-foreground">
              <X size={20} />
            </button>
            <AdminSidebar activeKey={activeKey} onNavigate={() => setSidebarOpen(false)} />
          </aside>
        </>
      )}

      {/* Main */}
      <div className="flex flex-1 flex-col lg:pr-64">
        {/* Top bar */}
        <header className="sticky top-0 z-20 glass-header border-b border-border">
          <div className="flex h-16 items-center justify-between px-4 sm:px-6">
            <div className="flex items-center gap-3">
              <button onClick={() => setSidebarOpen(true)} className="lg:hidden" aria-label="القائمة">
                <Menu size={22} />
              </button>
              <Link href="/" className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl brand-gradient-bg text-white">
                  <Package2 size={18} />
                </div>
                <div>
                  <h1 className="text-sm font-extrabold leading-none">لوحة التحكم</h1>
                  <p className="text-[10px] text-muted-foreground">المركز العلمي</p>
                </div>
              </Link>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative hidden sm:block">
                <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input placeholder="بحث..." className="w-48 rounded-lg border border-input bg-background py-2 pr-9 pl-3 text-sm outline-none" />
              </div>
              <button className="relative flex h-9 w-9 items-center justify-center rounded-lg hover:bg-muted">
                <Bell size={18} />
                <span className="absolute top-1.5 right-2 h-2 w-2 rounded-full bg-danger" />
              </button>
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-full brand-gradient-bg text-sm font-bold text-white">
                  أ
                </div>
                <span className="hidden text-sm font-medium sm:block">المدير</span>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 sm:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}

function AdminSidebar({ activeKey, onNavigate }: { activeKey: string; onNavigate?: () => void }) {
  return (
    <div className="flex h-full flex-col">
      <div className="flex h-16 items-center gap-2 border-b border-border px-4">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl brand-gradient-bg text-white">
          <Package2 size={18} />
        </div>
        <div>
          <h1 className="text-sm font-extrabold leading-none">المركز العلمي</h1>
          <p className="text-[10px] text-muted-foreground">Admin Panel</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto p-3">
        {navItems.map((item) => (
          <button
            key={item.key}
            onClick={onNavigate}
            className={cn(
              'mb-1 flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium transition-colors',
              activeKey === item.key
                ? 'brand-gradient-bg text-white shadow-soft'
                : 'text-foreground/70 hover:bg-muted'
            )}
          >
            <item.icon size={18} />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="border-t border-border p-3">
        <Link href="/" className="flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium text-destructive transition-colors hover:bg-destructive/10">
          <LogOut size={18} />
          تسجيل الخروج
        </Link>
      </div>
    </div>
  );
}
