'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, ShoppingBag, BookOpen, Truck, Tag } from 'lucide-react';
import Link from 'next/link';
import { cn } from '@/lib/utils';

interface Slide {
  title: string;
  subtitle: string;
  description: string;
  cta: { label: string; href: string };
  cta2: { label: string; href: string };
  icon: React.ReactNode;
  badge: string;
  image: string;
}

const slides: Slide[] = [
  {
    badge: 'عرض محدود',
    title: 'خصومات العودة للمدارس',
    subtitle: 'وفّر حتى 40%',
    description: 'تشكيلة واسعة من الكتب والأدوات المدرسية بأفضل الأسعار. عروض حصرية على جميع الفئات لعودة مدرسية ناجحة.',
    cta: { label: 'تسوق الآن', href: '/offers' },
    cta2: { label: 'تصفح الكتب', href: '/category/secondary' },
    icon: <Tag size={24} />,
    image: 'https://images.pexels.com/photos/6147085/pexels-photo-6147085.jpeg?auto=compress&cs=tinysrgb&w=1600',
  },
  {
    badge: 'احجز كتبك الآن',
    title: 'الكتب الخارجية الأصلية',
    subtitle: 'مراجع عالمية',
    description: 'أكبر تشكيلة من الكتب الخارجية لجميع المراحل التعليمية. كتب أصلية 100% من دور النشر العالمية المعتمدة.',
    cta: { label: 'تسوق الآن', href: '/category/secondary' },
    cta2: { label: 'تصفح الكتب', href: '/category/primary-school' },
    icon: <BookOpen size={24} />,
    image: 'https://images.pexels.com/photos/256541/pexels-photo-256541.jpeg?auto=compress&cs=tinysrgb&w=1600',
  },
  {
    badge: 'خدمة سريعة',
    title: 'توصيل سريع لكل المملكة',
    subtitle: 'خلال 1-3 أيام',
    description: 'خدمة توصيل سريعة وآمنة لجميع مدن المملكة. شحن مجاني للطلبات فوق 200 ر.س. تتبع طلبك في كل خطوة.',
    cta: { label: 'تسوق الآن', href: '/category/stationery' },
    cta2: { label: 'تصفح الكتب', href: '/track-order' },
    icon: <Truck size={24} />,
    image: 'https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?auto=compress&cs=tinysrgb&w=1600',
  },
  {
    badge: 'أفضل الأسعار',
    title: 'أفضل الأسعار والجودة',
    subtitle: 'ضمان الأصالة',
    description: 'نضمن لك أفضل الأسعار مع جودة عالية وأصلية. منتجات مختارة بعناية لتناسب احتياجاتك الدراسية والمكتبية.',
    cta: { label: 'تسوق الآن', href: '/offers' },
    cta2: { label: 'تصفح الكتب', href: '/category/gifts' },
    icon: <ShoppingBag size={24} />,
    image: 'https://images.pexels.com/photos/7977866/pexels-photo-7977866.jpeg?auto=compress&cs=tinysrgb&w=1600',
  },
];

export function HeroSlider() {
  const [current, setCurrent] = React.useState(0);
  const [direction, setDirection] = React.useState(1);

  const goTo = (index: number) => {
    setDirection(index > current ? 1 : -1);
    setCurrent(index);
  };

  const next = () => {
    setDirection(1);
    setCurrent((prev) => (prev + 1) % slides.length);
  };

  const prev = () => {
    setDirection(-1);
    setCurrent((prev) => (prev - 1 + slides.length) % slides.length);
  };

  React.useEffect(() => {
    const interval = setInterval(next, 6000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [current]);

  const slide = slides[current];

  return (
    <section className="relative overflow-hidden">
      <div className="container-px mx-auto max-w-7xl py-6">
        <div className="relative h-[420px] overflow-hidden rounded-3xl sm:h-[480px] lg:h-[520px]">
          <AnimatePresence mode="wait" custom={direction}>
            <motion.div
              key={current}
              custom={direction}
              initial={{ opacity: 0, x: direction > 0 ? 100 : -100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: direction > 0 ? -100 : 100 }}
              transition={{ duration: 0.5, ease: 'easeOut' }}
              className="absolute inset-0"
            >
              {/* Background image */}
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={slide.image}
                alt={slide.title}
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-l from-primary/95 via-primary/70 to-primary/30" />

              {/* Content */}
              <div className="absolute inset-0 flex items-center">
                <div className="container-px mx-auto max-w-7xl w-full">
                  <div className="max-w-lg">
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                      className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/20 px-4 py-1.5 text-sm font-semibold text-white backdrop-blur-md"
                    >
                      {slide.icon}
                      {slide.badge}
                    </motion.div>

                    <motion.h1
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                      className="text-3xl font-extrabold text-white drop-shadow-lg sm:text-4xl lg:text-5xl"
                    >
                      {slide.title}
                    </motion.h1>

                    <motion.p
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 }}
                      className="mt-2 text-xl font-bold text-white/90 sm:text-2xl"
                    >
                      {slide.subtitle}
                    </motion.p>

                    <motion.p
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5 }}
                      className="mt-4 text-sm leading-relaxed text-white/80 sm:text-base"
                    >
                      {slide.description}
                    </motion.p>

                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.6 }}
                      className="mt-6 flex flex-wrap gap-3"
                    >
                      <Link
                        href={slide.cta.href}
                        className="inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3 font-bold text-primary shadow-lg transition-transform hover:scale-105"
                      >
                        <ShoppingBag size={18} />
                        {slide.cta.label}
                      </Link>
                      <Link
                        href={slide.cta2.href}
                        className="inline-flex items-center gap-2 rounded-xl border-2 border-white/40 bg-white/10 px-6 py-3 font-bold text-white backdrop-blur-md transition-all hover:bg-white/20"
                      >
                        <BookOpen size={18} />
                        {slide.cta2.label}
                      </Link>
                    </motion.div>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation arrows */}
          <button
            onClick={prev}
            aria-label="السابق"
            className="absolute top-1/2 -translate-y-1/2 right-4 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-white/20 text-white backdrop-blur-md transition-all hover:bg-white/30"
          >
            <ChevronRight size={22} />
          </button>
          <button
            onClick={next}
            aria-label="التالي"
            className="absolute top-1/2 -translate-y-1/2 left-4 z-10 flex h-11 w-11 items-center justify-center rounded-full bg-white/20 text-white backdrop-blur-md transition-all hover:bg-white/30"
          >
            <ChevronLeft size={22} />
          </button>

          {/* Dots */}
          <div className="absolute bottom-4 left-1/2 z-10 flex -translate-x-1/2 gap-2">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => goTo(i)}
                aria-label={`الشريحة ${i + 1}`}
                className={cn(
                  'h-2 rounded-full transition-all',
                  i === current ? 'w-8 bg-white' : 'w-2 bg-white/40 hover:bg-white/60'
                )}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
